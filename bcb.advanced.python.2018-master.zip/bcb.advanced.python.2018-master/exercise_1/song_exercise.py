'''
    Paul Villanueva
    BCBGSO Advanced Python Workshop
    3/23/2018

    
'''



songs = ['days_go_by.txt', 'friday.txt', 'last_friday_night.txt',
         'monday.txt', 'summer_days.txt', 'sunday.txt', 'ten_days.txt'
         'tuesday.txt', 'sunday_morning.txt']

