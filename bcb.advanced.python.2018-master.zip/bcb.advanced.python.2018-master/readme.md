# BCBGSO 2018 Advanced Python Workshop 

The materials for the annual Advanced Python Workshop organized by the BCB Graduate Student Organization at Iowa State University.

Send questions, comments, and feedback to pev at iastate dot edu.