'''
    Paul Villanueva
    BCBGSO 2018 Advanced Python Workshop
    
'''

# The function below squares a number.  Run this code and call it on a
# couple different numbers.

def square(n):
    return n * n

# Write a function named cube that cubes the input number.

# Define a function square_area that takes the width and a length of a square
# and returns its area.

# Define a function peek that takes a file and prints out ONLY the first line.
# We will need to do something similar to this later today.
# Run the code and try it on a few files.
##def peek( ... ):
##    '''
##        in - a file name
##        out - the first line in the file
##    '''


# Modify peek so that it also prints out the length of the first line.


